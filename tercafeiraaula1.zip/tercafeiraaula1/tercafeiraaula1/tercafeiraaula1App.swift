//
//  tercafeiraaula1App.swift
//  tercafeiraaula1
//
//  Created by COTEMIG on 11/03/25.
//

import SwiftUI

@main
struct tercafeiraaula1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
